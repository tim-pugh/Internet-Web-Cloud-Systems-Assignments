Recipe booklet.

For now, we hardcode recipes and have ingredients, reviews, and time to cook!
